-- ==========================================================
-- 1. TABLES: USERS & AUTHENTICATION
-- ==========================================================
CREATE TABLE IF NOT EXISTS public.users (
    id SERIAL PRIMARY KEY,
    full_name TEXT NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL, 
    role TEXT CHECK (role IN ('admin', 'user')) DEFAULT 'user',
    status TEXT DEFAULT 'active', 
    created_at TIMESTAMP DEFAULT now()
);

-- ==========================================================
-- 2. TABLE: ANNOUNCEMENTS (Announcement Board)
-- ==========================================================
CREATE TABLE IF NOT EXISTS public.announcements (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT,
    created_by INT REFERENCES public.users(id),
    ref_no TEXT UNIQUE,
    status TEXT CHECK (status IN ('pending', 'approved', 'rejected')) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT now()
);

-- ==========================================================
-- 3. TABLE: PORTAL RECORDS (Program, Music, & Reports)
-- ==========================================================
-- FIX: Idinagdag ang 'created_at' para sa list sorting (Admin Review Portal)
CREATE TABLE IF NOT EXISTS public.portal_records (
    id SERIAL PRIMARY KEY,
    category TEXT CHECK (category IN ('program', 'music')), 
    title TEXT NOT NULL,
    in_charge TEXT NOT NULL, 
    details JSONB, 
    status TEXT CHECK (status IN ('pending', 'approved', 'rejected')) DEFAULT 'pending',
    ref_no TEXT UNIQUE,
    submitted_at TIMESTAMP DEFAULT now(),
    created_at TIMESTAMP DEFAULT now() 
);

-- ==========================================================
-- 4. FUNCTION: CONSOLIDATED REF NO GENERATOR
-- ==========================================================
CREATE OR REPLACE FUNCTION public.generate_mcb_system_ref()
RETURNS TRIGGER AS $$
DECLARE
    year_prefix TEXT := to_char(now(), 'YYYY');
    random_suffix TEXT := upper(substring(md5(random()::text) from 1 for 4));
    final_prefix TEXT;
BEGIN
    IF (TG_TABLE_NAME = 'portal_records') THEN
        IF (NEW.category = 'music') THEN
            final_prefix := 'MCB-MUS';
        ELSE
            final_prefix := 'MCB-PRG';
        END IF;
    ELSIF (TG_TABLE_NAME = 'announcements') THEN
        final_prefix := 'MCB-ANN';
    END IF;
    
    NEW.ref_no := final_prefix || '-' || year_prefix || '-' || random_suffix;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================
-- 5. TRIGGERS: AUTO-EXECUTE BEFORE INSERT
-- ==========================================================
-- Portal Records Trigger
DROP TRIGGER IF EXISTS tr_portal_ref_gen ON public.portal_records;
CREATE TRIGGER tr_portal_ref_gen
BEFORE INSERT ON public.portal_records
FOR EACH ROW
EXECUTE FUNCTION public.generate_mcb_system_ref();

-- Announcements Trigger
DROP TRIGGER IF EXISTS tr_announcement_ref_gen ON public.announcements;
CREATE TRIGGER tr_announcement_ref_gen
BEFORE INSERT ON public.announcements
FOR EACH ROW
EXECUTE FUNCTION public.generate_mcb_system_ref();

-- ==========================================================
-- 6. SECURITY: ROW LEVEL SECURITY (RLS) & POLICIES
-- ==========================================================

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portal_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable all for portal_records" ON public.portal_records;
DROP POLICY IF EXISTS "Enable all for announcements" ON public.announcements;
DROP POLICY IF EXISTS "Enable all for users" ON public.users;

-- --- POLICIES ---
CREATE POLICY "Enable all for users" ON public.users
FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Enable all for portal_records" ON public.portal_records
FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Enable all for announcements" ON public.announcements
FOR ALL USING (true) WITH CHECK (true);

-- ==========================================================
-- 7. INITIAL DATA (Admin & User Samples)
-- ==========================================================
-- Walang email na isinama para magtugma sa iyong login logic
INSERT INTO public.users (full_name, username, password, role, status) VALUES 
('System Admin', 'admin_mcb', 'Admin@123', 'admin', 'active'),
('Mark Brian Angco', 'mark_user', 'User@2026', 'user', 'active')
ON CONFLICT (username) DO NOTHING;

INSERT INTO public.portal_records (category, title, in_charge, details) VALUES 
('program', 'Sunday Service', 'Bro. Mark Brian', '{"flow": [{"activity": "Opening", "person": "Bro. Mark"}]}'),
('music', 'Worship Line-up', 'Sis. Jane Doe', '{"praise_list": ["Song 1"], "worship_list": ["Song 2"]}')
ON CONFLICT (ref_no) DO NOTHING;
